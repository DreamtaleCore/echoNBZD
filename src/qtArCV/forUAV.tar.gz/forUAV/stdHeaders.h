#ifndef STDHEADERS_H
#define STDHEADERS_H

// include extra std libraries
#include <algorithm>
#include <vector>
#include <iostream>
#include <fstream>
#include <stdio.h>

// include std io libraries
#include <iostream>
#include <string>
#include <stack>
#include <cmath>

using namespace std;

#endif // STDHEADERS_H
